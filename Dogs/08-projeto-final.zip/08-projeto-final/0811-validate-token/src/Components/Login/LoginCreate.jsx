import React from 'react';

const LoginCreate = () => {
  return <div>Login Criar</div>;
};

export default LoginCreate;
