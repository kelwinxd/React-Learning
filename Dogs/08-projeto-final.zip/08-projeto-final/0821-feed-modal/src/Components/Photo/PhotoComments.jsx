import React from 'react';

const PhotoComments = () => {
  return <div></div>;
};

export default PhotoComments;
